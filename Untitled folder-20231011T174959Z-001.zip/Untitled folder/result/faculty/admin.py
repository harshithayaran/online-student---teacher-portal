from django.contrib import admin
from .models import faculty_login

# Register your models here.
admin.site.register(faculty_login)